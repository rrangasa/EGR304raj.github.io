/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA2 aliases
#define LDR_TRIS                 TRISAbits.TRISA2
#define LDR_LAT                  LATAbits.LATA2
#define LDR_PORT                 PORTAbits.RA2
#define LDR_WPU                  WPUAbits.WPUA2
#define LDR_OD                   ODCONAbits.ODCA2
#define LDR_ANS                  ANSELAbits.ANSELA2
#define LDR_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define LDR_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define LDR_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define LDR_GetValue()           PORTAbits.RA2
#define LDR_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define LDR_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define LDR_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define LDR_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define LDR_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define LDR_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define LDR_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define LDR_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RB4 aliases
#define BTN_TRIS                 TRISBbits.TRISB4
#define BTN_LAT                  LATBbits.LATB4
#define BTN_PORT                 PORTBbits.RB4
#define BTN_WPU                  WPUBbits.WPUB4
#define BTN_OD                   ODCONBbits.ODCB4
#define BTN_ANS                  ANSELBbits.ANSELB4
#define BTN_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define BTN_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define BTN_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define BTN_GetValue()           PORTBbits.RB4
#define BTN_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define BTN_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define BTN_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define BTN_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define BTN_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define BTN_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define BTN_SetAnalogMode()      do { ANSELBbits.ANSELB4 = 1; } while(0)
#define BTN_SetDigitalMode()     do { ANSELBbits.ANSELB4 = 0; } while(0)

// get/set RC0 aliases
#define Sensor_input_TRIS                 TRISCbits.TRISC0
#define Sensor_input_LAT                  LATCbits.LATC0
#define Sensor_input_PORT                 PORTCbits.RC0
#define Sensor_input_WPU                  WPUCbits.WPUC0
#define Sensor_input_OD                   ODCONCbits.ODCC0
#define Sensor_input_ANS                  ANSELCbits.ANSELC0
#define Sensor_input_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define Sensor_input_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define Sensor_input_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define Sensor_input_GetValue()           PORTCbits.RC0
#define Sensor_input_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define Sensor_input_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define Sensor_input_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define Sensor_input_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define Sensor_input_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define Sensor_input_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define Sensor_input_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define Sensor_input_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC7 aliases
#define Speaker_Out_TRIS                 TRISCbits.TRISC7
#define Speaker_Out_LAT                  LATCbits.LATC7
#define Speaker_Out_PORT                 PORTCbits.RC7
#define Speaker_Out_WPU                  WPUCbits.WPUC7
#define Speaker_Out_OD                   ODCONCbits.ODCC7
#define Speaker_Out_ANS                  ANSELCbits.ANSELC7
#define Speaker_Out_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define Speaker_Out_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define Speaker_Out_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define Speaker_Out_GetValue()           PORTCbits.RC7
#define Speaker_Out_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define Speaker_Out_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define Speaker_Out_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define Speaker_Out_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define Speaker_Out_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define Speaker_Out_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define Speaker_Out_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define Speaker_Out_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD4 aliases
#define LED_TRIS                 TRISDbits.TRISD4
#define LED_LAT                  LATDbits.LATD4
#define LED_PORT                 PORTDbits.RD4
#define LED_WPU                  WPUDbits.WPUD4
#define LED_OD                   ODCONDbits.ODCD4
#define LED_ANS                  ANSELDbits.ANSELD4
#define LED_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define LED_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define LED_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define LED_GetValue()           PORTDbits.RD4
#define LED_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define LED_SetPullup()          do { WPUDbits.WPUD4 = 1; } while(0)
#define LED_ResetPullup()        do { WPUDbits.WPUD4 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONDbits.ODCD4 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONDbits.ODCD4 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELDbits.ANSELD4 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELDbits.ANSELD4 = 0; } while(0)

// get/set RD5 aliases
#define Sensor_State_TRIS                 TRISDbits.TRISD5
#define Sensor_State_LAT                  LATDbits.LATD5
#define Sensor_State_PORT                 PORTDbits.RD5
#define Sensor_State_WPU                  WPUDbits.WPUD5
#define Sensor_State_OD                   ODCONDbits.ODCD5
#define Sensor_State_ANS                  ANSELDbits.ANSELD5
#define Sensor_State_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define Sensor_State_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define Sensor_State_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define Sensor_State_GetValue()           PORTDbits.RD5
#define Sensor_State_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define Sensor_State_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define Sensor_State_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define Sensor_State_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define Sensor_State_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define Sensor_State_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define Sensor_State_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define Sensor_State_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RD6 aliases
#define Motor_Out_TRIS                 TRISDbits.TRISD6
#define Motor_Out_LAT                  LATDbits.LATD6
#define Motor_Out_PORT                 PORTDbits.RD6
#define Motor_Out_WPU                  WPUDbits.WPUD6
#define Motor_Out_OD                   ODCONDbits.ODCD6
#define Motor_Out_ANS                  ANSELDbits.ANSELD6
#define Motor_Out_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define Motor_Out_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define Motor_Out_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define Motor_Out_GetValue()           PORTDbits.RD6
#define Motor_Out_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define Motor_Out_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define Motor_Out_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define Motor_Out_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define Motor_Out_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define Motor_Out_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define Motor_Out_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define Motor_Out_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RF0 aliases
#define IO_RF0_TRIS                 TRISFbits.TRISF0
#define IO_RF0_LAT                  LATFbits.LATF0
#define IO_RF0_PORT                 PORTFbits.RF0
#define IO_RF0_WPU                  WPUFbits.WPUF0
#define IO_RF0_OD                   ODCONFbits.ODCF0
#define IO_RF0_ANS                  ANSELFbits.ANSELF0
#define IO_RF0_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define IO_RF0_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define IO_RF0_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define IO_RF0_GetValue()           PORTFbits.RF0
#define IO_RF0_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define IO_RF0_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define IO_RF0_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define IO_RF0_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define IO_RF0_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define IO_RF0_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define IO_RF0_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define IO_RF0_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define IO_RF1_TRIS                 TRISFbits.TRISF1
#define IO_RF1_LAT                  LATFbits.LATF1
#define IO_RF1_PORT                 PORTFbits.RF1
#define IO_RF1_WPU                  WPUFbits.WPUF1
#define IO_RF1_OD                   ODCONFbits.ODCF1
#define IO_RF1_ANS                  ANSELFbits.ANSELF1
#define IO_RF1_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define IO_RF1_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define IO_RF1_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define IO_RF1_GetValue()           PORTFbits.RF1
#define IO_RF1_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define IO_RF1_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define IO_RF1_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define IO_RF1_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define IO_RF1_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define IO_RF1_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define IO_RF1_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define IO_RF1_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/